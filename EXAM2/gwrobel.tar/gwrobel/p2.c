#include<stdlib.h>
#include<stdio.h>

int main(int argc, char *argv[]){

	printf("The quotient of 100 and 3 is %d and the remainder is %d\n", div(100,3).quot, div(100,3).rem);

	return 0;
}
